const express = require('express');
const User = require('../models/User');
const Task = require('../models/Task');
const router = express.Router();

// CREATE: Create a new user
router.post('/users', async (req, res) => {
  try {
    const user = new User(req.body);
    const savedUser = await user.save();
    res.status(201).json(savedUser);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// CREATE: Create a new task for a user
router.post('/tasks', async (req, res) => {
  try {
    const task = new Task(req.body);
    const savedTask = await task.save();
    // Populate user data
    const populatedTask = await Task.findById(savedTask._id).populate('userId');
    res.status(201).json(populatedTask);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// READ: Get all users
router.get('/users', async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// READ: Get all tasks with populated user data
router.get('/tasks', async (req, res) => {
  try {
    const tasks = await Task.find()
      .populate('userId', 'name email')
      .sort({ createdAt: -1 });
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// READ: Get tasks by user ID with population
router.get('/users/:userId/tasks', async (req, res) => {
  try {
    const tasks = await Task.find({ userId: req.params.userId })
      .populate('userId', 'name email')
      .sort({ createdAt: -1 });
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// UPDATE: Toggle task completion
router.patch('/tasks/:id/toggle', async (req, res) => {
  try {
    const task = await Task.findByIdAndUpdate(
      req.params.id,
      { completed: true },
      { new: true, runValidators: true }
    ).populate('userId', 'name email');
    
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    res.json(task);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});
router.get('/test', async (req, res) => {
  res.json({
    message: '🚀 API is running!',
    endpoints: {
      'POST /api/users': 'Create user',
      'POST /api/tasks': 'Create task',
      'GET /api/users': 'Get all users',
      'GET /api/tasks': 'Get all tasks',
      'GET /api/users/:id/tasks': 'Get user tasks'
    },
    sampleData: {
      createUser: {
        name: 'Test User',
        email: 'test@example.com'
      }
    }
  });
});

module.exports = router;