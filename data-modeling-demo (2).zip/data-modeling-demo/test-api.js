const axios = require('axios');

async function testAPI() {
  const BASE_URL = 'http://localhost:3000/api';
  
  console.log('🧪 Starting API Tests...\n');
  
  // Test 1: Create User
  console.log('1. Creating user...');
  const userRes = await axios.post(`${BASE_URL}/users`, {
    name: 'Test User',
    email: 'test@example.com'
  });
  console.log('✅ User created:', userRes.data._id);
  
  // Test 2: Create Task
  console.log('\n2. Creating task...');
  const taskRes = await axios.post(`${BASE_URL}/tasks`, {
    title: 'Test Task',
    description: 'Automated test task',
    userId: userRes.data._id
  });
  console.log('✅ Task created:', taskRes.data);
  
  // Test 3: Get all tasks (with population)
  console.log('\n3. Fetching tasks...');
  const tasksRes = await axios.get(`${BASE_URL}/tasks`);
  console.log('✅ Tasks with populated user:', JSON.stringify(tasksRes.data, null, 2));
  
  console.log('\n🎉 All tests passed!');
}

testAPI().catch(console.error);