console.log("=== STEP 2: Conditional Statements ===");
console.log("=====================================");

let score = 85;
let temperature = 25;
let isLoggedIn = true;

console.log(`Score: ${score}`);
console.log(`Temperature: ${temperature}°C`);
console.log(`Logged In: ${isLoggedIn}`);

if (score >= 90) {
    console.log("Excellent! You got an A+!");
} else if (score >= 80) {
    console.log("Great job! You got an A!");
} else if (score >= 70) {
    console.log("Good work! You got a B!");
} else if (score >= 60) {
    console.log("Keep studying! You got a C.");
} else {
    console.log("Try harder next time! You got a D.");
}

console.log("--- Weather Check ---");
if (temperature > 30) {
    console.log("It's HOT! Stay hydrated!");
} else if (temperature > 20) {
    console.log("Perfect weather!");
} else if (temperature > 10) {
    console.log("Wear a jacket.");
} else {
    console.log("Brrr! It's freezing!");
}

console.log("--- Login Status ---");
if (isLoggedIn) {
    console.log("Welcome back!");
} else {
    console.log("Please log in.");
}

console.log("\n");

console.log("=== STEP 3: Loops ===");
console.log("=====================");

// For Loop - Countdown
console.log("--- Countdown (For Loop) ---");
for (let i = 10; i >= 1; i--) {
    console.log(`T-minus ${i}...`);
}
console.log("Launch!");

console.log("\n--- Number Guessing (While Loop) ---");
let secretNumber = 7;
let guess = 1;
let maxAttempts = 5;

while (guess <= maxAttempts) {
    console.log(`Attempt ${guess}: Is it ${secretNumber}? ${guess === secretNumber ? 'YES!' : 'No, try again...'}`);
    if (guess === secretNumber) {
        console.log("Correct! You win!");
        break;
    }
    guess++;
}

if (guess > maxAttempts) {
    console.log(" Game Over! The number was 7.");
}

console.log("\n--- Multiplication Table (For Loop) ---");
for (let i = 1; i <= 5; i++) {
    console.log(`5 × ${i} = ${5 * i}`);
}

console.log("\n");

console.log("=== STEP 4: Functions ===");
console.log("=========================");

function getGrade(score) {
    if (score >= 90) return "A+";
    if (score >= 80) return "A";
    if (score >= 70) return "B";
    if (score >= 60) return "C";
    return "F";
}

console.log("--- Grade Calculator ---");
console.log(`Score 95: ${getGrade(95)}`);
console.log(`Score 82: ${getGrade(82)}`);
console.log(`Score 45: ${getGrade(45)}`);

function getWeatherAdvice(temp) {
    if (temp > 30) return "Hot - Stay cool!";
    if (temp > 20) return "Perfect day!";
    if (temp > 10) return "Chilly - Layer up!";
    return "Cold - Stay warm!";
}

console.log("\n--- Weather Advisor ---");
console.log(`25°C: ${getWeatherAdvice(25)}`);
console.log(`35°C: ${getWeatherAdvice(35)}`);
console.log(`5°C: ${getWeatherAdvice(5)}`);

function fizzBuzz(n) {
    let result = "";
    for (let i = 1; i <= n; i++) {
        if (i % 3 === 0 && i % 5 === 0) {
            result += "FizzBuzz ";
        } else if (i % 3 === 0) {
            result += "Fizz ";
        } else if (i % 5 === 0) {
            result += "Buzz ";
        } else {
            result += `${i} `;
        }
    }
    return result.trim();
}

console.log("\n--- FizzBuzz (1-15) ---");
console.log(fizzBuzz(15));

function generateWelcome(name, isPremium = false) {
    const status = isPremium ? "Premium Member" : "Member";
    return `Welcome ${status}, ${name}!`;
}

console.log("\n--- Welcome Messages ---");
console.log(generateWelcome("Alice"));
console.log(generateWelcome("Bob", true));

console.log("\nLAB COMPLETE! All steps implemented successfully!");