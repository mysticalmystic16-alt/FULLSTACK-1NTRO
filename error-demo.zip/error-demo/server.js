const express = require('express');
const demoRoutes = require('./routes/demoRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = 3000;

// 1. JSON parsing
app.use(express.json());

// 2. Demo routes
app.use('/api', demoRoutes);

// 3. 404 handler - FIXED VERSION
app.use((req, res, next) => {
  const error = new Error(`Route ${req.originalUrl} not found`);
  error.status = 404;
  next(error);
});

// 4. ERROR MIDDLEWARE (LAST!)
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`🌐 Server: http://localhost:${PORT}`);
  console.log(`✅ http://localhost:${PORT}/api/success`);
  console.log(`❌ http://localhost:${PORT}/api/error`);
});