const express = require('express');
const router = express.Router();

// ✅ SUCCESS
router.get('/success', (req, res) => {
  res.json({ success: true, message: '✅ All good!' });
});

// ❌ SYNC ERROR
router.get('/error', (req, res) => {
  throw new Error('💥 Sync error!');
});

// ❌ VALIDATION ERROR
router.get('/validation-error', (req, res, next) => {
  const error = new Error('Invalid data');
  error.status = 400;
  next(error);
});

// ❌ ASYNC ERROR
router.post('/async-error', async (req, res, next) => {
  throw new Error('💥 Async error!');
});

module.exports = router;